import json, os
from datetime import datetime
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func
from .config import settings
from .db import Base, engine as db_engine, get_db
from .models import Customer, AgentDecision, RecoveryAction, Payment
from .schemas import *
from .ml import engine as ml_engine
from .agent import agent
from .payment import configured, client, verify_payment, verify_webhook

Base.metadata.create_all(bind=db_engine)
app=FastAPI(title=settings.app_name, version="1.0.0", description="AI-powered e-commerce revenue intelligence and recovery API")
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in settings.cors_origins.split(',')], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.on_event("startup")
def seed():
    db=next(get_db())
    try:
        if db.query(Customer).count()==0:
            for _,r in ml_engine.customer_data.iterrows():
                db.add(Customer(customer_id=int(r.customer_id),total_revenue=float(r.total_revenue),total_sessions=int(r.total_sessions),total_carts=int(r.total_carts),total_purchases=int(r.total_purchases),abandoned_carts=int(r.abandoned_carts),purchase_probability=float(r.purchase_probability),revenue_opportunity=float(r.revenue_opportunity),priority_score=float(r.priority_score),priority=str(r.priority),opportunity_type=str(r.opportunity_type),recommended_action=str(r.recommended_action),reasons=json.dumps(list(r.reasons)),last_activity=str(r.last_activity)))
            db.commit()
        # refresh decisions without creating duplicates on every boot
        if db.query(AgentDecision).count()==0:
            for r in db.query(Customer).filter(Customer.priority.in_(["HIGH","MEDIUM"])).order_by(Customer.priority_score.desc()).limit(100).all():
                x=agent.deterministic(r.customer_id)
                db.add(AgentDecision(customer_id=r.customer_id,priority=x["priority"],opportunity_type=x["opportunity_type"],revenue_opportunity=x["revenue_opportunity"],purchase_probability=x["purchase_probability"],recommended_action=x["recommended_action"],reasons=json.dumps(x["reasons"]),explanation=x["explanation"]))
            db.commit()
    finally: db.close()

@app.get("/", tags=["system"])
def root(): return {"name":settings.app_name,"status":"ok","docs":"/docs"}
@app.get("/health", tags=["system"])
def health(): return {"status":"healthy","gemini_configured":bool(settings.gemini_api_key),"razorpay_test_mode_configured":configured()}

@app.get("/dashboard/summary",response_model=DashboardSummary)
def summary(db:Session=Depends(get_db)):
    opportunity=db.query(func.coalesce(func.sum(Customer.revenue_opportunity),0)).scalar() or 0
    at_risk=db.query(Customer).filter(Customer.priority.in_(["HIGH","MEDIUM"])).count()
    high=db.query(Customer).filter(Customer.priority=="HIGH").count()
    abandoned=db.query(func.coalesce(func.sum(Customer.abandoned_carts),0)).scalar() or 0
    recovered=db.query(func.coalesce(func.sum(Payment.amount),0)).filter(Payment.status=="SUCCESS").scalar() or 0
    total_payments=db.query(Payment).count(); success_count=db.query(Payment).filter(Payment.status=="SUCCESS").count()
    rate=(success_count/total_payments*100) if total_payments else 0
    return DashboardSummary(estimated_revenue_opportunity=float(opportunity),customers_at_risk=at_risk,high_priority=high,recovered_revenue=float(recovered),abandoned_carts=int(abandoned),recovery_rate=rate,pulse=rate)

@app.get("/customers")
def customers(search:str|None=None,priority:str|None=None,status:str|None=None,page:int=1,page_size:int=25,include_recovered:bool=False,db:Session=Depends(get_db)):
    q=db.query(Customer)
    if not include_recovered:
        recovered_ids=[r[0] for r in db.query(RecoveryAction.customer_id).filter(RecoveryAction.status=="SUCCESS").distinct().all()]
        if recovered_ids: q=q.filter(~Customer.customer_id.in_(recovered_ids))
    if search and search.isdigit(): q=q.filter(Customer.customer_id==int(search))
    if priority: q=q.filter(Customer.priority==priority.upper())
    page=max(1,page); page_size=min(max(1,page_size),100); total=q.count(); rows=q.order_by(Customer.priority_score.desc()).offset((page-1)*page_size).limit(page_size).all()
    return {"items":[serialize_customer(x) for x in rows],"total":total,"page":page,"page_size":page_size,"pages":(total+page_size-1)//page_size}

def serialize_customer(x):
    return {"customer_id":x.customer_id,"total_revenue":x.total_revenue,"total_sessions":x.total_sessions,"total_carts":x.total_carts,"total_purchases":x.total_purchases,"abandoned_carts":x.abandoned_carts,"purchase_probability":x.purchase_probability,"revenue_opportunity":x.revenue_opportunity,"priority_score":x.priority_score,"priority":x.priority,"opportunity_type":x.opportunity_type,"recommended_action":x.recommended_action,"reasons":json.loads(x.reasons or '[]'),"last_activity":x.last_activity}

@app.get("/customers/{customer_id}",response_model=CustomerDetail)
def customer_detail(customer_id:int,db:Session=Depends(get_db)):
    c=db.get(Customer,customer_id)
    if not c: raise HTTPException(404,"Customer not found")
    sessions=ml_engine.sessions(customer_id)
    timeline=[]
    for _,r in sessions.tail(12).iterrows():
        timeline.append({"date":str(r.get("visit_date","")),"label":"Abandoned cart" if int(r.cart_abandoned)==1 else ("Purchased" if int(r.purchased)==1 else ("Added to cart" if int(r.added_to_cart)==1 else "Visited")),"detail":f"Product {int(r.product_id)} · {str(r.product_category)}"})
    insight=agent.explain(customer_id)
    history=[]
    for a in db.query(RecoveryAction).filter(RecoveryAction.customer_id==customer_id).order_by(RecoveryAction.created_at.desc()).limit(20): history.append({"id":a.id,"action":a.action,"opportunity":a.opportunity,"status":a.status,"created_at":a.created_at.isoformat()})
    return CustomerDetail(**serialize_customer(c),timeline=timeline,ai_insight=insight,recovery_history=history)

@app.get("/agent-decisions")
def decisions(db:Session=Depends(get_db)):
    return [{"id":x.id,"customer_id":x.customer_id,"priority":x.priority,"opportunity_type":x.opportunity_type,"revenue_opportunity":x.revenue_opportunity,"purchase_probability":x.purchase_probability,"recommended_action":x.recommended_action,"reasons":json.loads(x.reasons),"explanation":x.explanation,"created_at":x.created_at.isoformat()} for x in db.query(AgentDecision).order_by(AgentDecision.created_at.desc()).limit(200)]

@app.get("/recovery-actions",response_model=list[RecoveryOut])
def recoveries(db:Session=Depends(get_db)): return db.query(RecoveryAction).order_by(RecoveryAction.created_at.desc()).limit(200).all()

MAX_RECOVERY_ATTEMPTS=3

@app.post("/recovery-actions",response_model=RecoveryOut)
def create_recovery(payload:RecoveryCreate,db:Session=Depends(get_db)):
    c=db.get(Customer,payload.customer_id)
    if not c: raise HTTPException(404,"Customer not found")
    if payload.action not in {"personalized_cart_recovery","new_customer_conversion","priority_recovery_campaign","targeted_recovery_offer","monitor"}: raise HTTPException(422,"Unsupported recovery action")
    # stopping rule: recovery stops automatically after a successful payment
    if db.query(RecoveryAction).filter(RecoveryAction.customer_id==c.customer_id,RecoveryAction.status=="SUCCESS").first():
        raise HTTPException(409,"This customer has already been successfully recovered. Recovery stops automatically after a successful payment.")
    # stopping rule: reuse an in-flight recovery instead of creating a duplicate
    active=db.query(RecoveryAction).filter(RecoveryAction.customer_id==c.customer_id,RecoveryAction.status.in_(["PENDING","PROCESSING"])).order_by(RecoveryAction.created_at.desc()).first()
    if active: return active
    # stopping rule: bounded number of failed attempts
    failed=db.query(RecoveryAction).filter(RecoveryAction.customer_id==c.customer_id,RecoveryAction.status=="FAILED").count()
    if failed>=MAX_RECOVERY_ATTEMPTS:
        raise HTTPException(409,f"Recovery attempt limit reached ({MAX_RECOVERY_ATTEMPTS}) for this customer.")
    a=RecoveryAction(customer_id=c.customer_id,action=payload.action,opportunity=c.revenue_opportunity,status="PENDING")
    db.add(a); db.commit(); db.refresh(a); return a

@app.post("/payments/create-order")
def create_order(payload:PaymentCreate,db:Session=Depends(get_db)):
    a=db.get(RecoveryAction,payload.recovery_action_id)
    if not a: raise HTTPException(404,"Recovery action not found")
    if a.status=="SUCCESS": raise HTTPException(409,"This recovery has already been completed.")
    if not configured(): raise HTTPException(503,"Razorpay Test Mode not configured.")
    amount=max(100,float(a.opportunity))
    order=client().order.create(data={"amount":int(round(amount*100)),"currency":"INR","receipt":f"recovery_{a.id}_{int(datetime.utcnow().timestamp())}","notes":{"customer_id":str(a.customer_id),"recovery_action_id":str(a.id),"source":"revenue_leak_detective"}})
    db.add(Payment(customer_id=a.customer_id,recovery_action_id=a.id,razorpay_order_id=order["id"],amount=amount,status="PENDING")); a.status="PROCESSING"; db.commit()
    return {"key_id":settings.razorpay_key_id,"order_id":order["id"],"amount":int(round(amount*100)),"currency":"INR","customer_id":a.customer_id,"recovery_action_id":a.id,"mode":"test"}

@app.post("/payments/verify")
def verify(payload:PaymentVerify,db:Session=Depends(get_db)):
    p=db.query(Payment).filter(Payment.razorpay_order_id==payload.razorpay_order_id).first()
    if not p: raise HTTPException(404,"Payment record not found")
    try:
        verify_payment(payload.razorpay_order_id,payload.razorpay_payment_id,payload.razorpay_signature)
    except Exception:
        p.status="FAILED"
        if p.recovery_action_id:
            a=db.get(RecoveryAction,p.recovery_action_id)
            if a: a.status="FAILED"
        db.commit()
        raise HTTPException(400,"Payment verification failed")
    p.razorpay_payment_id=payload.razorpay_payment_id; p.status="SUCCESS"
    if p.recovery_action_id:
        a=db.get(RecoveryAction,p.recovery_action_id); a.status="SUCCESS"; a.completed_at=datetime.utcnow()
    db.commit(); return {"status":"SUCCESS","message":"Payment verified and recovery updated."}

@app.post("/webhooks/razorpay")
async def webhook(request:Request,db:Session=Depends(get_db)):
    body=await request.body(); signature=request.headers.get("X-Razorpay-Signature","")
    if not verify_webhook(body,signature): raise HTTPException(400,"Invalid webhook signature")
    data=await request.json(); event_id=request.headers.get("X-Razorpay-Event-Id") or data.get("event_id")
    if event_id and db.query(Payment).filter(Payment.event_id==event_id).first(): return {"status":"ok","duplicate":True}
    event=data.get("event",""); entity=data.get("payload",{}).get("payment",{}).get("entity",{})
    if event in {"payment.captured","payment.authorized"}:
        order_id=entity.get("order_id"); p=db.query(Payment).filter(Payment.razorpay_order_id==order_id).first()
        if p:
            p.status="SUCCESS"; p.razorpay_payment_id=entity.get("id"); p.event_id=event_id
            if p.recovery_action_id:
                a=db.get(RecoveryAction,p.recovery_action_id); a.status="SUCCESS"; a.completed_at=datetime.utcnow()
    db.commit(); return {"status":"ok"}

@app.get("/insights")
def insights(db:Session=Depends(get_db)):
    df=ml_engine.df
    out=[]
    channel=df.groupby("marketing_channel")["cart_abandoned"].mean().sort_values(ascending=False)
    if len(channel): out.append({"title":"Highest abandonment channel","value":str(channel.index[0]),"detail":f"{channel.iloc[0]*100:.1f}% of sessions in this channel abandoned carts.","severity":"warning"})
    device=df.groupby("device_type")["cart_abandoned"].mean().sort_values(ascending=False)
    if len(device): out.append({"title":"Highest abandonment device","value":str(device.index[0]),"detail":f"{device.iloc[0]*100:.1f}% abandonment rate in the dataset.","severity":"warning"})
    category=df.groupby("product_category")["cart_abandoned"].mean().sort_values(ascending=False)
    if len(category): out.append({"title":"Highest-leak category","value":str(category.index[0]),"detail":f"{category.iloc[0]*100:.1f}% abandonment rate.","severity":"info"})
    repeat=db.query(Customer).filter(Customer.abandoned_carts>=2).count(); out.append({"title":"Repeated abandonment","value":str(repeat),"detail":"Customers with two or more abandoned carts.","severity":"danger"})
    return out
